package com.android.launcher3.folder;

/* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
/* JADX INFO: loaded from: classes.dex */
public final class ClippedFolderIconLayoutRule {
    public float mAvailableSpace;
    public float mBaselineIconScale;
    public float mIconSize;
    public boolean mIsRtl;
    public float mRadius;
    public float[] mTmpPoint;

    public final void getGridPosition(int i10, int i11, float[] fArr) {
        getPosition(0, 4, fArr);
        float f10 = fArr[0];
        float f11 = fArr[1];
        getPosition(3, 4, fArr);
        float f12 = fArr[0] - f10;
        float f13 = fArr[1] - f11;
        fArr[0] = (i11 * f12) + f10;
        fArr[1] = (i10 * f13) + f11;
    }

    public final void getPosition(int i10, int i11, float[] fArr) {
        int i12 = i10;
        int iMax = Math.max(i11, 2);
        boolean z10 = this.mIsRtl;
        double d10 = 0.0d;
        double d11 = z10 ? 0.0d : 3.141592653589793d;
        int i13 = z10 ? 1 : -1;
        if (iMax == 3) {
            d10 = 1.5707963267948966d;
        } else if (iMax == 4) {
            d10 = 0.7853981633974483d;
        }
        double d12 = i13;
        double d13 = (d10 * d12) + d11;
        if (iMax == 4 && i12 == 3) {
            i12 = 2;
        } else if (iMax == 4 && i12 == 2) {
            i12 = 3;
        }
        float f10 = ((iMax == 3 ? 0.15f : iMax == 4 ? 0.12f : 0.0f) + 1.0f) * this.mRadius;
        double d14 = ((6.283185307179586d / ((double) iMax)) * ((double) i12) * d12) + d13;
        float fScaleForItem = (scaleForItem(iMax, 0) * this.mIconSize) / 2.0f;
        fArr[0] = ((this.mAvailableSpace / 2.0f) + ((float) ((Math.cos(d14) * ((double) f10)) / 2.0d))) - fScaleForItem;
        fArr[1] = ((this.mAvailableSpace / 2.0f) + ((float) ((Math.sin(d14) * ((double) (-f10))) / 2.0d))) - fScaleForItem;
    }

    public final float scaleForItem(int i10, int i11) {
        float f10 = 0.44f;
        if (i11 <= 0 && i10 <= 3) {
            f10 = 0.51f;
        }
        return f10 * this.mBaselineIconScale;
    }
}
