package com.android.launcher3.folder;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.util.FloatProperty;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import com.android.launcher3.BubbleTextView;
import com.android.launcher3.CellLayout;
import com.android.launcher3.DeviceProfile;
import com.android.launcher3.Hotseat;
import com.android.launcher3.Launcher;
import com.android.launcher3.LauncherAnimUtils;
import com.android.launcher3.ShortcutAndWidgetContainer;
import com.android.launcher3.Utilities;
import com.android.launcher3.Workspace;
import com.android.launcher3.apppairs.AppPairIcon;
import com.android.launcher3.celllayout.CellLayoutLayoutParams;
import com.android.launcher3.graphics.ShapeDelegate;
import com.android.launcher3.icons.GraphicsUtils;
import com.android.launcher3.statehandlers.LauncherDepthController;
import com.android.launcher3.uioverrides.QuickstepLauncher;
import com.android.launcher3.util.MultiPropertyFactory;
import com.android.launcher3.views.BaseDragLayer;
import com.android.launcher3.views.ScrimView;
import com.android.systemui.plugins.DarkIconDispatcher;
import com.google.android.apps.nexuslauncher.R;
import java.lang.invoke.VarHandle;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
/* JADX INFO: loaded from: classes.dex */
public final class FolderAnimationSpringBuilderManager {
    public Folder folder;
    public LauncherDelegate launcherDelegate;
    public ShapeDelegate shapeDelegate;

    public final AnimatorSet createAnimatorSet(boolean z10) {
        BubbleTextView bubbleTextView;
        int i10;
        boolean z11;
        BubbleTextView bubbleTextView2;
        LauncherDepthController launcherDepthController;
        MultiPropertyFactory.MultiProperty folderZoom;
        BubbleTextView bubbleTextView3;
        int i11;
        LauncherDelegate launcherDelegate = this.launcherDelegate;
        Float fValueOf = Float.valueOf(1.0f);
        Launcher launcher = launcherDelegate.getLauncher();
        if (launcher != null) {
            Workspace workspace = launcher.mWorkspace;
            Hotseat hotseat = launcher.mHotseat;
            workspace.setPivotToScaleWithSelf(hotseat);
            LauncherAnimUtils.WORKSPACE_SCALE_PROPERTY_FACTORY.get(5).set(workspace, fValueOf);
            LauncherAnimUtils.HOTSEAT_SCALE_PROPERTY_FACTORY.get(5).set(hotseat, fValueOf);
        }
        Folder folder = this.folder;
        BaseDragLayer.LayoutParams layoutParams = (BaseDragLayer.LayoutParams) folder.getLayoutParams();
        PreviewBackground previewBackground = folder.mFolderIcon.mBackground;
        FolderGridOrganizer folderGridOrganizerCreateFolderGridOrganizer = FolderGridOrganizer.createFolderGridOrganizer(folder.mActivityContext.getDeviceProfile());
        folderGridOrganizerCreateFolderGridOrganizer.setFolderInfo(folder.mInfo);
        ArrayList arrayListPreviewItemsForPage = folderGridOrganizerCreateFolderGridOrganizer.previewItemsForPage(0, folder.getIconsInReadingOrder());
        float fScaleForItem = folder.mFolderIcon.getLayoutRule().mIconSize * folder.mFolderIcon.getLayoutRule().scaleForItem(arrayListPreviewItemsForPage.size(), 0);
        Rect rect = new Rect();
        float descendantRectRelativeToSelf = folder.mActivityContext.getDragLayer().getDescendantRectRelativeToSelf(folder.mFolderIcon, rect);
        int scaledRadius = previewBackground.getScaledRadius();
        View view = (View) arrayListPreviewItemsForPage.get(0);
        if (view instanceof AppPairIcon) {
            bubbleTextView = ((AppPairIcon) view).titleTextView;
            if (bubbleTextView == null) {
                bubbleTextView = null;
            }
        } else {
            bubbleTextView = (BubbleTextView) view;
        }
        float f10 = scaledRadius * 2 * descendantRectRelativeToSelf;
        float f11 = (fScaleForItem / bubbleTextView.mIconSize) * descendantRectRelativeToSelf;
        int i12 = Utilities.isRtl(folder.getContext().getResources()) ? (int) ((((FrameLayout.LayoutParams) layoutParams).width * f11) - f10) : 0;
        int paddingLeft = (int) (folder.mContent.getPaddingLeft() * f11);
        int paddingTop = (int) (folder.mContent.getPaddingTop() * f11);
        int iRound = ((Math.round((previewBackground.basePreviewOffsetX - (previewBackground.getScaledRadius() - (previewBackground.previewSize / 2))) * descendantRectRelativeToSelf) + (folder.getPaddingLeft() + rect.left)) - paddingLeft) - i12;
        int iRound2 = (Math.round((previewBackground.basePreviewOffsetY - (previewBackground.getScaledRadius() - (previewBackground.previewSize / 2))) * descendantRectRelativeToSelf) + (folder.getPaddingTop() + rect.top)) - paddingTop;
        float contentAreaHeight = folder.getContentAreaHeight() - (folder.getContentAreaHeight() * f11);
        int scaledRadius2 = previewBackground.getScaledRadius() - (previewBackground.previewSize / 2);
        float f12 = z10 ? f11 : 1.0f;
        float f13 = f11 / descendantRectRelativeToSelf;
        float f14 = iRound - layoutParams.f11663x;
        float f15 = iRound2 - layoutParams.f11664y;
        int i13 = paddingLeft + i12;
        int i14 = ((int) (i12 / descendantRectRelativeToSelf)) + scaledRadius2;
        int integer = folder.mContent.getResources().getInteger(R.integer.config_materialFolderExpandDuration);
        ShapeDelegate shapeDelegate = this.shapeDelegate;
        GradientDrawable gradientDrawable = folder.mBackground;
        DeviceProfile deviceProfile = folder.mActivityContext.getDeviceProfile();
        Rect rect2 = new Rect(i13, paddingTop, Math.round(i13 + f10), Math.round(paddingTop + f10));
        Rect rect3 = new Rect(0, 0, folder.getLayoutParams().width, folder.getLayoutParams().height);
        float cornerRadius = gradientDrawable.getCornerRadius();
        FolderPagedView folderPagedView = folder.mContent;
        int currentPage = z10 ? folderPagedView.getCurrentPage() : folderPagedView.getDestinationPage();
        if (Utilities.isRtl(folder.getContext().getResources())) {
            currentPage = (folder.mContent.getPageCount() - 1) - currentPage;
        }
        int i15 = currentPage * folder.getLayoutParams().width;
        int i16 = (int) ((deviceProfile.mFolderProfile.folderIconSizePx / f11) * 0.125f);
        float f16 = i15;
        boolean z12 = true;
        Rect rect4 = new Rect(((int) ((rect2.left / f11) + f16)) - i16, ((int) (rect2.top / f11)) - i16, ((int) ((rect2.right / f11) + f16)) + i16, ((int) (rect2.bottom / f11)) + i16);
        Rect rect5 = new Rect(i15, 0, folder.getLayoutParams().width + i15, folder.getLayoutParams().height);
        FolderPagedView folderPagedView2 = folder.mContent;
        int currentPage2 = z10 ? folderPagedView2.getCurrentPage() : folderPagedView2.getDestinationPage();
        ArrayList iconsInReadingOrder = folder.getIconsInReadingOrder();
        int pageCount = folder.mContent.getPageCount() - 1;
        int size = iconsInReadingOrder.size();
        int i17 = folder.mContent.mOrganizer.mMaxItemsPerPage;
        int i18 = currentPage2 == pageCount ? size - (i17 * currentPage2) : i17;
        int i19 = i17 * currentPage2;
        ArrayList arrayList = new ArrayList(i18);
        int i20 = i19;
        for (int iMin = Math.min(i19 + i18, iconsInReadingOrder.size()); i20 < iMin; iMin = iMin) {
            arrayList.add((View) iconsInReadingOrder.get(i20));
            i20++;
        }
        int size2 = arrayList.size();
        FolderGridOrganizer folderGridOrganizerCreateFolderGridOrganizer2 = FolderGridOrganizer.createFolderGridOrganizer(folder.mActivityContext.getDeviceProfile());
        folderGridOrganizerCreateFolderGridOrganizer2.setFolderInfo(folder.mInfo);
        ArrayList arrayListPreviewItemsForPage2 = folderGridOrganizerCreateFolderGridOrganizer2.previewItemsForPage(currentPage2, folder.getIconsInReadingOrder());
        CellLayout cellLayout = (CellLayout) folder.mContent.getChildAt(0);
        ShortcutAndWidgetContainer shortcutAndWidgetContainer = cellLayout != null ? cellLayout.mShortcutsAndWidgets : null;
        ClippedFolderIconLayoutRule layoutRule = folder.mFolderIcon.getLayoutRule();
        FolderGridOrganizer folderGridOrganizerCreateFolderGridOrganizer3 = FolderGridOrganizer.createFolderGridOrganizer(folder.mActivityContext.getDeviceProfile());
        folderGridOrganizerCreateFolderGridOrganizer3.setFolderInfo(folder.mInfo);
        int i21 = folderGridOrganizerCreateFolderGridOrganizer3.mCountX;
        int i22 = z10 ? 0 : size2 * 5;
        ArrayList arrayList2 = new ArrayList();
        int i23 = i22;
        int i24 = 0;
        while (i24 < size2) {
            View view2 = (View) arrayList.get(i24);
            ArrayList arrayList3 = arrayList;
            CellLayoutLayoutParams cellLayoutLayoutParams = (CellLayoutLayoutParams) view2.getLayoutParams();
            float f17 = contentAreaHeight;
            cellLayoutLayoutParams.isLockedToGrid = z12;
            if (shortcutAndWidgetContainer != null) {
                shortcutAndWidgetContainer.setupLp(view2);
            }
            ShortcutAndWidgetContainer shortcutAndWidgetContainer2 = shortcutAndWidgetContainer;
            float fScaleForItem2 = layoutRule.mIconSize * layoutRule.scaleForItem(size2, currentPage2);
            if (view2 instanceof AppPairIcon) {
                bubbleTextView3 = ((AppPairIcon) view2).titleTextView;
                if (bubbleTextView3 == null) {
                    bubbleTextView3 = null;
                }
            } else {
                bubbleTextView3 = (BubbleTextView) view2;
            }
            float f18 = fScaleForItem2 / bubbleTextView3.mIconSize;
            float f19 = f18 / f13;
            int i25 = currentPage2;
            float f20 = z10 ? f19 : 1.0f;
            view2.setScaleX(f20);
            view2.setScaleY(f20);
            float[] fArr = layoutRule.mTmpPoint;
            if (size2 > 4 || i25 != 0) {
                i11 = size2;
                layoutRule.getGridPosition(i24 / i21, i24 % i21, fArr);
            } else {
                layoutRule.getPosition(i24, size2, fArr);
                i11 = size2;
            }
            float f21 = fArr[0];
            int i26 = (int) (((f21 - (((int) ((((ViewGroup.MarginLayoutParams) cellLayoutLayoutParams).width - r15) * f18)) / 2)) + i14) / f13);
            int paddingTop2 = (int) (((fArr[1] + scaledRadius2) - (view2.getPaddingTop() * f18)) / f13);
            float f22 = i26 - cellLayoutLayoutParams.f10282x;
            float f23 = paddingTop2 - cellLayoutLayoutParams.f10283y;
            IconAnimationData iconAnimationData = new IconAnimationData();
            iconAnimationData.icon = view2;
            iconAnimationData.iconDelay = i23;
            iconAnimationData.itemsInPreview = arrayListPreviewItemsForPage2;
            iconAnimationData.xDistance = f22;
            iconAnimationData.yDistance = f23;
            iconAnimationData.initialIconScale = f19;
            iconAnimationData.isOpening = z10;
            VarHandle.storeStoreFence();
            arrayList2.add(iconAnimationData);
            i23 = z10 ? i23 + 5 : i23 - 5;
            i24++;
            contentAreaHeight = f17;
            arrayList = arrayList3;
            shortcutAndWidgetContainer = shortcutAndWidgetContainer2;
            currentPage2 = i25;
            size2 = i11;
            z12 = true;
        }
        AnimatorSet animatorSet = new AnimatorSet();
        folder.mFolderIcon.mPreviewItemManager.recomputePreviewDrawingParams();
        folder.setPivotX(0.0f);
        folder.setPivotY(0.0f);
        FolderPagedView folderPagedView3 = folder.mContent;
        folderPagedView3.setScaleX(f12);
        folderPagedView3.setScaleY(f12);
        folderPagedView3.setPivotX(0.0f);
        folderPagedView3.setPivotY(0.0f);
        LinearLayout linearLayout = folder.mFooter;
        linearLayout.setScaleX(f12);
        linearLayout.setScaleY(f12);
        linearLayout.setPivotX(0.0f);
        linearLayout.setPivotY(0.0f);
        FolderSpringAnimatorSet$Factory.playSpringAnimation(folder.getContext(), animatorSet, z10, 0, 380.0f, 0.8f, f14, 0.0f, 1.0f, LauncherAnimUtils.VIEW_TRANSLATE_X, folder);
        Context context = folder.getContext();
        FloatProperty floatProperty = LauncherAnimUtils.VIEW_TRANSLATE_Y;
        FolderSpringAnimatorSet$Factory.playSpringAnimation(context, animatorSet, z10, 0, 380.0f, 0.8f, f15, 0.0f, 1.0f, floatProperty, folder);
        FolderSpringAnimatorSet$Factory.playSpringAnimation(folder.getContext(), animatorSet, z10, 0, 380.0f, 0.8f, f11, 1.0f, 0.002f, LauncherAnimUtils.getScaleProperty(), folder.mContent);
        FolderSpringAnimatorSet$Factory.playSpringAnimation(folder.getContext(), animatorSet, z10, 0, 380.0f, 0.8f, f11, 1.0f, 0.002f, LauncherAnimUtils.getScaleProperty(), folder.mFooter);
        FolderSpringAnimatorSet$Factory.playSpringAnimation(folder.getContext(), animatorSet, z10, 0, 380.0f, 0.8f, -contentAreaHeight, 0.0f, 1.0f, floatProperty, folder.mFooter);
        FolderSpringAnimatorSet$Factory.playSpringAnimation(folder.getContext(), animatorSet, z10, z10 ? integer / 2 : 0, 380.0f, 0.8f, -folder.getElevation(), 0.0f, 1.0f, LauncherAnimUtils.VIEW_TRANSLATE_Z, folder);
        FolderOpenCloseAnimationListener folderOpenCloseAnimationListener = new FolderOpenCloseAnimationListener();
        folderOpenCloseAnimationListener.folder = folder;
        VarHandle.storeStoreFence();
        animatorSet.addListener(folderOpenCloseAnimationListener);
        animatorSet.play(shapeDelegate.createRevealAnimator(folder, rect2, rect3, cornerRadius, !z10));
        if (!z10) {
            animatorSet.play(shapeDelegate.createRevealAnimator(folder.mContent, rect4, rect5, cornerRadius, true));
        }
        GradientDrawable gradientDrawable2 = folder.mBackground;
        int attrColor = GraphicsUtils.getAttrColor(folder.getContext(), R.attr.folderPreviewColor);
        int attrColor2 = GraphicsUtils.getAttrColor(folder.getContext(), R.attr.folderBackgroundColor);
        gradientDrawable2.mutate();
        gradientDrawable2.setColor(z10 ? attrColor : attrColor2);
        int i27 = z10 ? attrColor : attrColor2;
        if (z10) {
            attrColor = attrColor2;
        }
        ObjectAnimator objectAnimatorOfArgb = ObjectAnimator.ofArgb(gradientDrawable2, "color", i27, attrColor);
        objectAnimatorOfArgb.setDuration(integer);
        animatorSet.play(objectAnimatorOfArgb);
        if (folder.getItemCount() <= 4 || !z10) {
            i10 = 0;
        } else {
            folder.mFooter.setAlpha(0.0f);
            i10 = integer - 128;
        }
        Context context2 = folder.getContext();
        int i28 = z10 ? i10 : 0;
        FloatProperty floatProperty2 = LauncherAnimUtils.VIEW_ALPHA;
        FolderSpringAnimatorSet$Factory.playSpringAnimation(context2, animatorSet, z10, i28, 1600.0f, 0.9f, 0.0f, 1.0f, 0.00390625f, floatProperty2, folder.mFooter);
        folder.mFolderName.setAlpha(z10 ? 0.0f : 1.0f);
        FolderSpringAnimatorSet$Factory.playSpringAnimation(folder.getContext(), animatorSet, z10, z10 ? 32 : 0, 1600.0f, 0.9f, 0.0f, 1.0f, 0.00390625f, floatProperty2, folder.mFolderName);
        Context context3 = folder.getContext();
        Launcher launcher2 = launcherDelegate.getLauncher();
        if (launcher2 == null) {
            z11 = z10;
        } else {
            ScrimView scrimView = launcher2.mScrimView;
            Workspace workspace2 = launcher2.mWorkspace;
            Hotseat hotseat2 = launcher2.mHotseat;
            FloatProperty floatProperty3 = LauncherAnimUtils.WORKSPACE_SCALE_PROPERTY_FACTORY.get(5);
            FloatProperty floatProperty4 = LauncherAnimUtils.HOTSEAT_SCALE_PROPERTY_FACTORY.get(5);
            float f24 = Utilities.isDarkTheme(context3) ? 0.32f : 0.2f;
            scrimView.setBackgroundColor(DarkIconDispatcher.DEFAULT_INVERSE_ICON_TINT);
            FolderSpringAnimatorSet$Factory.playSpringAnimation(context3, animatorSet, z10, 0, 380.0f, 0.98f, 0.0f, f24, 0.00390625f, floatProperty2, scrimView);
            floatProperty3.getClass();
            workspace2.getClass();
            z11 = z10;
            FolderSpringAnimatorSet$Factory.playSpringAnimation(context3, animatorSet, z11, 0, 380.0f, 0.98f, 1.0f, 0.975f, 0.002f, floatProperty3, workspace2);
            floatProperty4.getClass();
            hotseat2.getClass();
            FolderSpringAnimatorSet$Factory.playSpringAnimation(context3, animatorSet, z11, 0, 380.0f, 0.98f, 1.0f, 0.975f, 0.002f, floatProperty4, hotseat2);
            FolderScrimAnimationListener folderScrimAnimationListener = new FolderScrimAnimationListener();
            folderScrimAnimationListener.scrimView = scrimView;
            folderScrimAnimationListener.isOpening = z11;
            VarHandle.storeStoreFence();
            animatorSet.addListener(folderScrimAnimationListener);
        }
        Launcher launcher3 = launcherDelegate.getLauncher();
        if (launcher3 != null && (launcherDepthController = ((QuickstepLauncher) launcher3).mDepthController) != null && (folderZoom = launcherDepthController.getFolderZoom()) != null) {
            FolderSpringAnimatorSet$Factory.playSpringAnimation(folder.getContext(), animatorSet, z11, 0, 380.0f, 0.8f, 0.0f, 0.125f, 0.002f, MultiPropertyFactory.MULTI_PROPERTY_VALUE, folderZoom);
        }
        int size3 = arrayList2.size();
        int i29 = 0;
        while (i29 < size3) {
            Object obj = arrayList2.get(i29);
            i29++;
            IconAnimationData iconAnimationData2 = (IconAnimationData) obj;
            Context context4 = folder.getContext();
            View view3 = iconAnimationData2.icon;
            if (view3 instanceof AppPairIcon) {
                bubbleTextView2 = ((AppPairIcon) view3).titleTextView;
                if (bubbleTextView2 == null) {
                    bubbleTextView2 = null;
                }
            } else {
                bubbleTextView2 = (BubbleTextView) view3;
            }
            if (iconAnimationData2.isOpening) {
                bubbleTextView2.getFloatingViewTextAlpha().setValue(0.0f);
            }
            boolean z13 = iconAnimationData2.isOpening;
            int i30 = iconAnimationData2.iconDelay;
            if (z13) {
                i30 += 100;
            }
            FolderSpringAnimatorSet$Factory.playSpringAnimation(context4, animatorSet, z13, i30, 1600.0f, 0.9f, 0.0f, 1.0f, 0.00390625f, MultiPropertyFactory.MULTI_PROPERTY_VALUE, bubbleTextView2.getFloatingViewTextAlpha());
            if (!iconAnimationData2.itemsInPreview.contains(iconAnimationData2.icon)) {
                FolderSpringAnimatorSet$Factory.playSpringAnimation(context4, animatorSet, iconAnimationData2.isOpening, iconAnimationData2.iconDelay, 1600.0f, 0.9f, 0.0f, 1.0f, 0.00390625f, LauncherAnimUtils.VIEW_ALPHA, iconAnimationData2.icon);
            }
            FolderSpringAnimatorSet$Factory.playSpringAnimation(context4, animatorSet, iconAnimationData2.isOpening, iconAnimationData2.iconDelay, 380.0f, 0.8f, iconAnimationData2.xDistance, 0.0f, 1.0f, LauncherAnimUtils.VIEW_TRANSLATE_X, iconAnimationData2.icon);
            FolderSpringAnimatorSet$Factory.playSpringAnimation(context4, animatorSet, iconAnimationData2.isOpening, iconAnimationData2.iconDelay, 380.0f, 0.8f, iconAnimationData2.yDistance, 0.0f, 1.0f, LauncherAnimUtils.VIEW_TRANSLATE_Y, iconAnimationData2.icon);
            FolderSpringAnimatorSet$Factory.playSpringAnimation(context4, animatorSet, iconAnimationData2.isOpening, iconAnimationData2.iconDelay, 380.0f, 0.8f, iconAnimationData2.initialIconScale, 1.0f, 0.002f, LauncherAnimUtils.getScaleProperty(), iconAnimationData2.icon);
            final View view4 = iconAnimationData2.icon;
            final float f25 = iconAnimationData2.xDistance;
            final float f26 = iconAnimationData2.yDistance;
            final float f27 = iconAnimationData2.initialIconScale;
            final List list = iconAnimationData2.itemsInPreview;
            final boolean z14 = iconAnimationData2.isOpening;
            animatorSet.addListener(new AnimatorListenerAdapter() { // from class: com.android.launcher3.folder.FolderSpringAnimatorSet$Factory$getIconAnimatorListener$1
                @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
                public final void onAnimationEnd(Animator animator) {
                    super.onAnimationEnd(animator);
                    view4.setTranslationX(0.0f);
                    view4.setTranslationY(0.0f);
                    view4.setScaleX(1.0f);
                    view4.setScaleY(1.0f);
                    if (list.contains(view4)) {
                        return;
                    }
                    view4.setAlpha(1.0f);
                }

                @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
                public final void onAnimationStart(Animator animator) {
                    super.onAnimationStart(animator);
                    if (z14) {
                        view4.setTranslationX(f25);
                        view4.setTranslationY(f26);
                        view4.setScaleX(f27);
                        view4.setScaleY(f27);
                        if (list.contains(view4)) {
                            return;
                        }
                        view4.setAlpha(0.0f);
                    }
                }
            });
        }
        return animatorSet;
    }
}
