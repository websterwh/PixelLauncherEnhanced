package com.android.launcher3.folder;

import android.graphics.Point;
import android.util.Log;
import com.android.launcher3.DeviceProfile;
import com.android.launcher3.deviceprofile.FolderProfile;
import com.android.launcher3.model.data.FolderInfo;
import java.lang.invoke.VarHandle;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
/* JADX INFO: loaded from: classes.dex */
public final class FolderGridOrganizer {
    public int mCountX;
    public int mCountY;
    public boolean mDisplayingUpperLeftQuadrant;
    public int mMaxCountX;
    public int mMaxCountY;
    public int mMaxItemsPerPage;
    public int mNumItemsInFolder;
    public Point mPoint;

    public static FolderGridOrganizer createFolderGridOrganizer(DeviceProfile deviceProfile) {
        FolderProfile folderProfile = deviceProfile.mFolderProfile;
        int i10 = folderProfile.numColumns;
        int i11 = folderProfile.numRows;
        FolderGridOrganizer folderGridOrganizer = new FolderGridOrganizer();
        folderGridOrganizer.mPoint = new Point();
        folderGridOrganizer.mDisplayingUpperLeftQuadrant = false;
        folderGridOrganizer.mMaxCountX = i10;
        folderGridOrganizer.mMaxCountY = i11;
        folderGridOrganizer.mMaxItemsPerPage = i10 * i11;
        VarHandle.storeStoreFence();
        return folderGridOrganizer;
    }

    public final Point getPosForRank(int i10) {
        int i11 = i10 % this.mMaxItemsPerPage;
        int i12 = this.mCountX;
        Point point = this.mPoint;
        if (i12 == 0) {
            point.x = 0;
            point.y = 0;
        } else {
            point.x = i11 % i12;
            point.y = i11 / i12;
        }
        return this.mPoint;
    }

    public final boolean isItemInPreview(int i10, int i11) {
        if (i10 <= 0 && !this.mDisplayingUpperLeftQuadrant) {
            return i11 < 4;
        }
        int i12 = this.mCountX;
        return i11 % i12 < 2 && i11 / i12 < 2;
    }

    public final ArrayList previewItemsForPage(int i10, List list) {
        ArrayList arrayList = new ArrayList();
        int i11 = this.mCountX * this.mCountY;
        int i12 = i11 * i10;
        ArrayList arrayList2 = (ArrayList) list;
        int iMin = Math.min(i11 + i12, arrayList2.size());
        int i13 = 0;
        while (i12 < iMin) {
            if (isItemInPreview(i10, i13)) {
                arrayList.add(arrayList2.get(i12));
            }
            if (arrayList.size() == 4) {
                break;
            }
            i12++;
            i13++;
        }
        if (arrayList.isEmpty()) {
            Log.d("b/383526431", "previewItemsForPage: mCountX = " + this.mCountX + ", mCountY = " + this.mCountY + ", content size = " + arrayList2.size());
        }
        return arrayList;
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0032  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void setContentSize(int r9) {
        /*
            r8 = this;
            int r0 = r8.mNumItemsInFolder
            if (r9 == r0) goto L6a
            int r0 = r8.mMaxCountX
            int r1 = r8.mMaxCountY
            int r2 = r8.mCountX
            int r3 = r8.mCountY
            int r4 = r8.mMaxItemsPerPage
            r5 = 1
            r6 = 0
            if (r9 < r4) goto L16
            r2 = r0
            r3 = r1
            r4 = r5
            goto L17
        L16:
            r4 = r6
        L17:
            if (r4 != 0) goto L5d
            int r4 = r2 * r3
            if (r4 >= r9) goto L35
            if (r2 <= r3) goto L21
            if (r3 != r1) goto L28
        L21:
            if (r2 >= r0) goto L28
            int r4 = r2 + 1
            r7 = r4
        L26:
            r4 = r3
            goto L30
        L28:
            if (r3 >= r1) goto L2e
            int r4 = r3 + 1
            r7 = r2
            goto L30
        L2e:
            r7 = r2
            goto L26
        L30:
            if (r4 != 0) goto L52
            int r4 = r4 + 1
            goto L52
        L35:
            int r4 = r3 + (-1)
            int r7 = r4 * r2
            if (r7 < r9) goto L43
            if (r3 < r2) goto L43
            int r4 = java.lang.Math.max(r6, r4)
            r7 = r2
            goto L52
        L43:
            int r4 = r2 + (-1)
            int r7 = r4 * r3
            if (r7 < r9) goto L50
            int r4 = java.lang.Math.max(r6, r4)
            r7 = r4
        L4e:
            r4 = r3
            goto L52
        L50:
            r7 = r2
            goto L4e
        L52:
            if (r7 != r2) goto L58
            if (r4 != r3) goto L58
            r2 = r5
            goto L59
        L58:
            r2 = r6
        L59:
            r3 = r4
            r4 = r2
            r2 = r7
            goto L17
        L5d:
            r8.mCountX = r2
            r8.mCountY = r3
            r0 = 4
            if (r9 <= r0) goto L65
            goto L66
        L65:
            r5 = r6
        L66:
            r8.mDisplayingUpperLeftQuadrant = r5
            r8.mNumItemsInFolder = r9
        L6a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.launcher3.folder.FolderGridOrganizer.setContentSize(int):void");
    }

    public final void setFolderInfo(FolderInfo folderInfo) {
        setContentSize(folderInfo.contents.size());
    }
}
