package com.android.launcher3.folder;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Property;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.android.launcher3.Alarm;
import com.android.launcher3.BubbleTextView;
import com.android.launcher3.CheckLongPressHelper;
import com.android.launcher3.DeviceProfile;
import com.android.launcher3.DropTarget;
import com.android.launcher3.OnAlarmListener;
import com.android.launcher3.R$id;
import com.android.launcher3.Reorderable;
import com.android.launcher3.Utilities;
import com.android.launcher3.UtilitiesKt;
import com.android.launcher3.dagger.LauncherComponentProvider;
import com.android.launcher3.deviceprofile.WorkspaceProfile;
import com.android.launcher3.dot.DotInfo;
import com.android.launcher3.dot.FolderDotInfo;
import com.android.launcher3.dragndrop.BaseItemDragListener;
import com.android.launcher3.dragndrop.DraggableView;
import com.android.launcher3.graphics.ThemeManager;
import com.android.launcher3.homescreenfiles.HomeScreenFilesUtils;
import com.android.launcher3.icons.DotRenderer;
import com.android.launcher3.icons.GraphicsUtils;
import com.android.launcher3.model.data.AppPairInfo;
import com.android.launcher3.model.data.FolderInfo;
import com.android.launcher3.model.data.ItemInfo;
import com.android.launcher3.model.data.WorkspaceItemFactory;
import com.android.launcher3.model.data.WorkspaceItemInfo;
import com.android.launcher3.popup.IconViewController;
import com.android.launcher3.popup.Poppable;
import com.android.launcher3.touch.CustomEventsTouchHandler;
import com.android.launcher3.touch.WorkspaceItemCustomActionsListener;
import com.android.launcher3.util.MultiPropertyFactory;
import com.android.launcher3.util.MultiTranslateDelegate;
import com.android.launcher3.views.ActivityContext;
import com.android.launcher3.views.BaseDragLayer;
import com.android.launcher3.views.FloatingIconViewCompanion;
import com.android.systemui.plugins.keyguard.data.model.WeatherData;
import com.google.android.apps.nexuslauncher.R;
import java.lang.invoke.VarHandle;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
/* JADX INFO: loaded from: classes.dex */
public class FolderIcon extends FrameLayout implements FloatingIconViewCompanion, DraggableView, Reorderable, Poppable, IconViewController {
    public static final AnonymousClass1 DOT_SCALE_PROPERTY = new AnonymousClass1(Float.TYPE, "dotScale");
    public ActivityContext mActivity;
    public PreviewBackground mBackground;
    public boolean mBackgroundIsVisible;
    public final List mCurrentPreviewItems;
    public final CustomEventsTouchHandler mCustomEventsTouchHandler;

    @ViewDebug.ExportedProperty(category = "launcher", deepExport = WeatherData.DEBUG)
    public final FolderDotInfo mDotInfo;

    @ViewDebug.ExportedProperty(category = "launcher", deepExport = WeatherData.DEBUG)
    public final DotRenderer.DrawParams mDotParams;
    public DotRenderer mDotRenderer;
    public float mDotScale;
    public Animator mDotScaleAnim;
    public Folder mFolder;
    public BubbleTextView mFolderName;
    public boolean mForceHideDot;
    public FolderInfo mInfo;
    public final CheckLongPressHelper mLongPressHelper;
    public final AnonymousClass2 mOnOpenListener;
    public final Alarm mOpenAlarm;
    public final PreviewItemManager mPreviewItemManager;
    public final ClippedFolderIconLayoutRule mPreviewLayoutRule;
    public FolderGridOrganizer mPreviewVerifier;
    public float mScaleForReorderBounce;
    public PreviewItemDrawingParams mTmpParams;
    public final Rect mTouchArea;
    public final MultiTranslateDelegate mTranslateDelegate;

    /* JADX INFO: renamed from: com.android.launcher3.folder.FolderIcon$1, reason: invalid class name */
    /* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
    public final class AnonymousClass1 extends Property {
        @Override // android.util.Property
        public final Object get(Object obj) {
            return Float.valueOf(((FolderIcon) obj).mDotScale);
        }

        @Override // android.util.Property
        public final void set(Object obj, Object obj2) {
            FolderIcon folderIcon = (FolderIcon) obj;
            folderIcon.mDotScale = ((Float) obj2).floatValue();
            folderIcon.invalidate();
        }
    }

    /* JADX INFO: renamed from: com.android.launcher3.folder.FolderIcon$2, reason: invalid class name */
    /* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
    public final class AnonymousClass2 implements OnAlarmListener {
        public /* synthetic */ FolderIcon this$0;

        /* JADX WARN: Type inference fix 'apply assigned field type' failed
        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$PrimitiveArg
        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
         */
        @Override // com.android.launcher3.OnAlarmListener
        public final void onAlarm(Alarm alarm) {
            Folder folder = this.this$0.mFolder;
            folder.mIsExternalDrag = true;
            folder.mIsDragInProgress = true;
            folder.mActivityContext.getDragController().addDragListener(folder);
            ArrayList arrayList = new ArrayList(folder.mInfo.contents);
            folder.mEmptyCellRank = arrayList.size();
            arrayList.add(null);
            folder.animateOpen(folder.mEmptyCellRank / folder.mContent.mOrganizer.mMaxItemsPerPage, arrayList);
        }
    }

    /* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
    public interface FolderIconParent {
        void clearFolderLeaveBehind(FolderIcon folderIcon);

        void drawFolderLeaveBehindForIcon(FolderIcon folderIcon);
    }

    public FolderIcon(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mTranslateDelegate = new MultiTranslateDelegate(this);
        this.mBackground = new PreviewBackground(getContext());
        this.mBackgroundIsVisible = true;
        this.mTmpParams = new PreviewItemDrawingParams(0.0f, 0.0f, 0.0f);
        this.mCurrentPreviewItems = new ArrayList();
        this.mOpenAlarm = new Alarm(getContext().getMainLooper());
        this.mDotInfo = new FolderDotInfo();
        this.mTouchArea = new Rect();
        this.mScaleForReorderBounce = 1.0f;
        AnonymousClass2 anonymousClass2 = new AnonymousClass2();
        anonymousClass2.this$0 = this;
        VarHandle.storeStoreFence();
        this.mOnOpenListener = anonymousClass2;
        this.mLongPressHelper = new CheckLongPressHelper(null, this);
        FolderIcon$$ExternalSyntheticLambda0 folderIcon$$ExternalSyntheticLambda0 = new FolderIcon$$ExternalSyntheticLambda0(0);
        folderIcon$$ExternalSyntheticLambda0.f10358e = this;
        VarHandle.storeStoreFence();
        FolderIcon$$ExternalSyntheticLambda0 folderIcon$$ExternalSyntheticLambda02 = new FolderIcon$$ExternalSyntheticLambda0(1);
        folderIcon$$ExternalSyntheticLambda02.f10358e = this;
        VarHandle.storeStoreFence();
        this.mCustomEventsTouchHandler = new CustomEventsTouchHandler(this, folderIcon$$ExternalSyntheticLambda0, folderIcon$$ExternalSyntheticLambda02);
        ClippedFolderIconLayoutRule clippedFolderIconLayoutRule = new ClippedFolderIconLayoutRule();
        clippedFolderIconLayoutRule.mTmpPoint = new float[2];
        this.mPreviewLayoutRule = clippedFolderIconLayoutRule;
        this.mPreviewItemManager = new PreviewItemManager(this);
        DotRenderer.DrawParams drawParams = new DotRenderer.DrawParams();
        this.mDotParams = drawParams;
        drawParams.setDotColor(GraphicsUtils.getAttrColor(context, R.attr.notificationDotColor));
        drawParams.shapeInfo = ((ThemeManager) ThemeManager.INSTANCE.mFunction.apply(LauncherComponentProvider.get(context))).iconState.iconShapeInfo;
    }

    public static /* synthetic */ void a(FolderIcon folderIcon, MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        folderIcon.mLongPressHelper.onTouchEvent(motionEvent);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static FolderIcon inflateFolderAndIcon(int i10, Context context, ViewGroup viewGroup, FolderInfo folderInfo) {
        Rect rect = Folder.sTempRect;
        Folder folder = (Folder) LayoutInflater.from(context).cloneInContext(context).inflate(R.layout.user_folder_icon_normalized, (ViewGroup) null);
        ActivityContext activityContext = (ActivityContext) context;
        DeviceProfile deviceProfile = activityContext.getDeviceProfile();
        FolderIcon folderIcon = (FolderIcon) (viewGroup != null ? LayoutInflater.from(viewGroup.getContext()) : activityContext.getLayoutInflater()).inflate(i10, viewGroup, false);
        folderIcon.setClipToPadding(false);
        BubbleTextView bubbleTextView = (BubbleTextView) folderIcon.findViewById(R$id.folder_icon_name);
        folderIcon.mFolderName = bubbleTextView;
        bubbleTextView.applyLabel(folderInfo.title, null, false, false);
        folderIcon.mFolderName.setCompoundDrawablePadding(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) folderIcon.mFolderName.getLayoutParams();
        WorkspaceProfile workspaceProfile = deviceProfile.mWorkspaceProfile;
        layoutParams.topMargin = workspaceProfile.iconSizePx + workspaceProfile.iconDrawablePaddingPx;
        folderIcon.setTag(folderInfo);
        folderIcon.setOnClickListener(activityContext.getItemOnClickListener());
        folderIcon.mCustomEventsTouchHandler.customActionsListener = WorkspaceItemCustomActionsListener.INSTANCE;
        folderIcon.mInfo = folderInfo;
        folderIcon.mActivity = activityContext;
        folderIcon.mDotRenderer = new DotRenderer(deviceProfile.mWorkspaceProfile.iconSizePx);
        folderIcon.updateDotInfo();
        folderIcon.setContentDescription(folderIcon.getAccessiblityTitle(folderInfo.title));
        folderIcon.setAccessibilityDelegate(activityContext.getAccessibilityDelegate());
        FolderGridOrganizer folderGridOrganizerCreateFolderGridOrganizer = FolderGridOrganizer.createFolderGridOrganizer(activityContext.getDeviceProfile());
        folderIcon.mPreviewVerifier = folderGridOrganizerCreateFolderGridOrganizer;
        folderGridOrganizerCreateFolderGridOrganizer.setContentSize(folderInfo.contents.size());
        folderIcon.updatePreviewItems(false);
        folder.mFolderIcon = folderIcon;
        folder.mInfo = folderInfo;
        folder.mFromTitle = folderInfo.title;
        folder.mFromLabelState = folderInfo.getFromLabelState();
        folder.updateItemLocationsInDatabaseBatch(true);
        if (((BaseDragLayer.LayoutParams) folder.getLayoutParams()) == null) {
            BaseDragLayer.LayoutParams layoutParams2 = new BaseDragLayer.LayoutParams(0, 0);
            layoutParams2.customPosition = true;
            folder.setLayoutParams(layoutParams2);
        }
        folder.reapplyItemInfo();
        FolderIcon folderIcon2 = folder.mFolderIcon;
        Folder$$ExternalSyntheticLambda19 folder$$ExternalSyntheticLambda19 = new Folder$$ExternalSyntheticLambda19(3);
        folder$$ExternalSyntheticLambda19.f10351e = folder;
        VarHandle.storeStoreFence();
        folderIcon2.post(folder$$ExternalSyntheticLambda19);
        folderIcon.mFolder = folder;
        return folderIcon;
    }

    public final void animateDotScale(float... fArr) {
        Animator animator = this.mDotScaleAnim;
        if (animator != null) {
            animator.cancel();
        }
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, DOT_SCALE_PROPERTY, fArr);
        this.mDotScaleAnim = objectAnimatorOfFloat;
        objectAnimatorOfFloat.addListener(new AnimatorListenerAdapter() { // from class: com.android.launcher3.folder.FolderIcon.3
            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator2) {
                FolderIcon.this.mDotScaleAnim = null;
            }
        });
        this.mDotScaleAnim.start();
    }

    @Override // android.view.View
    public final void cancelLongPress() {
        super.cancelLongPress();
        this.mLongPressHelper.cancelLongPress();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        if (isSelected()) {
            UtilitiesKt.drawWorkspaceItemSelectionHighlight(canvas, this);
        }
        super.dispatchDraw(canvas);
        if (this.mBackgroundIsVisible) {
            this.mPreviewItemManager.recomputePreviewDrawingParams();
            PreviewBackground previewBackground = this.mBackground;
            if (previewBackground.mDrawingDelegate == null) {
                previewBackground.drawBackground(canvas);
            }
            if (this.mCurrentPreviewItems.isEmpty()) {
                return;
            }
            this.mPreviewItemManager.draw(canvas);
            PreviewBackground previewBackground2 = this.mBackground;
            if (previewBackground2.mDrawingDelegate == null) {
                previewBackground2.getClass();
            }
            drawDot(canvas);
        }
    }

    public final void drawDot(Canvas canvas) {
        if (this.mForceHideDot) {
            return;
        }
        FolderDotInfo folderDotInfo = this.mDotInfo;
        if ((folderDotInfo == null || folderDotInfo.mNumNotifications <= 0) && this.mDotScale <= 0.0f) {
            return;
        }
        Rect rect = this.mDotParams.iconBounds;
        int i10 = this.mActivity.getDeviceProfile().mWorkspaceProfile.iconSizePx;
        int width = (getWidth() - i10) / 2;
        rect.left = width;
        rect.right = width + i10;
        int paddingTop = getPaddingTop();
        rect.top = paddingTop;
        rect.bottom = paddingTop + i10;
        Utilities.scaleRectAboutCenter(rect, this.mBackground.previewSize / i10);
        DotRenderer.DrawParams drawParams = this.mDotParams;
        float f10 = this.mDotScale;
        PreviewBackground previewBackground = this.mBackground;
        drawParams.scale = Math.max(0.0f, f10 - (previewBackground.mIsHoveredOrAnimating ? 0.0f : (previewBackground.mScale - 1.0f) / 0.20000005f));
        this.mDotRenderer.draw(canvas, this.mDotParams);
    }

    public final String getAccessiblityTitle(CharSequence charSequence) {
        if (charSequence == null) {
            charSequence = getContext().getString(R.string.unnamed_folder);
        }
        int size = this.mInfo.contents.size();
        String string = getContext().getString(((Boolean) HomeScreenFilesUtils.isFeatureEnabled$delegate.getValue()).booleanValue() ? R.string.app_folder_type_name : R.string.folder_type_name);
        if (size < 4) {
            return getContext().getString(hasDot() ? R.string.apps_folder_name_format_exact_with_dot : R.string.apps_folder_name_format_exact, string, charSequence, Integer.valueOf(size));
        }
        return getContext().getString(hasDot() ? R.string.apps_folder_name_format_overflow_with_dot : R.string.apps_folder_name_format_overflow, string, charSequence, 4);
    }

    @Override // com.android.launcher3.popup.IconViewController
    public final MultiPropertyFactory.MultiProperty getFloatingViewTextAlpha() {
        return this.mFolderName.getFloatingViewTextAlpha();
    }

    @Override // com.android.launcher3.popup.IconViewController
    public final int getIconHeight() {
        Rect rect = new Rect();
        getPreviewBounds(rect);
        return rect.height();
    }

    public final ClippedFolderIconLayoutRule getLayoutRule() {
        if (this.mPreviewLayoutRule.mIconSize == 0.0f) {
            this.mPreviewItemManager.recomputePreviewDrawingParams();
        }
        return this.mPreviewLayoutRule;
    }

    public final void getPreviewBounds(Rect rect) {
        this.mPreviewItemManager.recomputePreviewDrawingParams();
        PreviewBackground previewBackground = this.mBackground;
        int i10 = previewBackground.basePreviewOffsetY;
        int i11 = previewBackground.basePreviewOffsetX;
        int i12 = previewBackground.previewSize;
        rect.set(i11, i10, i11 + i12, i12 + i10);
        Utilities.scaleRectAboutCenter(rect, 1.125f);
    }

    @Override // com.android.launcher3.Reorderable
    public final float getReorderBounceScale() {
        return this.mScaleForReorderBounce;
    }

    @Override // com.android.launcher3.Reorderable
    public final MultiTranslateDelegate getTranslateDelegate() {
        return this.mTranslateDelegate;
    }

    @Override // com.android.launcher3.dragndrop.DraggableView
    public final int getViewType() {
        return 0;
    }

    @Override // com.android.launcher3.dragndrop.DraggableView
    public final void getWorkspaceVisualDragBounds(Rect rect) {
        getPreviewBounds(rect);
    }

    public final boolean hasDot() {
        FolderDotInfo folderDotInfo = this.mDotInfo;
        return folderDotInfo != null && folderDotInfo.mNumNotifications > 0;
    }

    /* JADX WARN: Removed duplicated region for block: B:59:0x01cf  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0242  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x0245  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x024e  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x028e  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0293  */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$PrimitiveArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void onDrop(com.android.launcher3.model.data.ItemInfo r26, com.android.launcher3.DropTarget.DragObject r27, android.graphics.Rect r28, float r29, int r30, boolean r31) {
        /*
            Method dump skipped, instruction units count: 723
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.launcher3.folder.FolderIcon.onDrop(com.android.launcher3.model.data.ItemInfo, com.android.launcher3.DropTarget$DragObject, android.graphics.Rect, float, int, boolean):void");
    }

    @Override // android.view.View
    public final void onHoverChanged(boolean z10) {
        super.onHoverChanged(z10);
        PreviewBackground previewBackground = this.mBackground;
        previewBackground.animateScale(previewBackground.mIsAccepting, z10);
    }

    public final void onItemsChanged(boolean z10) {
        updatePreviewItems(false);
        updateDotInfo();
        setContentDescription(getAccessiblityTitle(this.mInfo.title));
        updatePreviewItems(z10);
        invalidate();
        requestLayout();
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i10, int i11) {
        if (this.mActivity.getDeviceProfile().mWorkspaceProfile.iconCenterVertically) {
            int i12 = this.mActivity.getDeviceProfile().mWorkspaceProfile.iconSizePx;
            Paint.FontMetrics fontMetrics = this.mFolderName.getPaint().getFontMetrics();
            setPadding(getPaddingLeft(), (View.MeasureSpec.getSize(i11) - ((this.mFolderName.getCompoundDrawablePadding() + i12) + ((int) Math.ceil(fontMetrics.bottom - fontMetrics.top)))) / 2, getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i10, i11);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        return this.mCustomEventsTouchHandler.onDelegateTouchEvent(motionEvent);
    }

    @Override // com.android.launcher3.views.FloatingIconViewCompanion, com.android.launcher3.popup.IconViewController
    public final void setForceHideDot(boolean z10) {
        if (this.mForceHideDot == z10) {
            return;
        }
        this.mForceHideDot = z10;
        if (z10) {
            invalidate();
        } else if (hasDot()) {
            animateDotScale(0.0f, 1.0f);
        }
    }

    @Override // com.android.launcher3.views.FloatingIconViewCompanion, com.android.launcher3.popup.IconViewController
    public final void setIconVisible(boolean z10) {
        this.mBackgroundIsVisible = z10;
        invalidate();
    }

    @Override // com.android.launcher3.Reorderable
    public final void setReorderBounceScale(float f10) {
        this.mScaleForReorderBounce = f10;
        super.setScaleX(f10);
        super.setScaleY(f10);
    }

    public final void updateDotInfo() {
        FolderDotInfo folderDotInfo = this.mDotInfo;
        boolean z10 = folderDotInfo.mNumNotifications > 0;
        folderDotInfo.mNumNotifications = 0;
        ArrayList arrayList = this.mInfo.contents;
        int size = arrayList.size();
        int i10 = 0;
        while (i10 < size) {
            Object obj = arrayList.get(i10);
            i10++;
            FolderDotInfo folderDotInfo2 = this.mDotInfo;
            DotInfo dotInfoForItem = this.mActivity.getDotInfoForItem((ItemInfo) obj);
            if (dotInfoForItem == null) {
                folderDotInfo2.getClass();
            } else {
                int size2 = ((ArrayList) dotInfoForItem.mNotificationKeys).size() + folderDotInfo2.mNumNotifications;
                folderDotInfo2.mNumNotifications = size2;
                folderDotInfo2.mNumNotifications = Utilities.boundToRange(size2, 0, 999);
            }
        }
        boolean z11 = this.mDotInfo.mNumNotifications > 0;
        float f10 = z11 ? 1.0f : 0.0f;
        if ((z11 ^ z10) && isShown()) {
            animateDotScale(f10);
            return;
        }
        Animator animator = this.mDotScaleAnim;
        if (animator != null) {
            animator.cancel();
        }
        this.mDotScale = f10;
        invalidate();
    }

    public final void updatePreviewItems(boolean z10) {
        PreviewItemManager previewItemManager = this.mPreviewItemManager;
        int size = previewItemManager.mFirstPageParams.size();
        previewItemManager.buildParamsForPage(0, previewItemManager.mFirstPageParams, z10);
        previewItemManager.mNumOfPrevItems = size;
        this.mCurrentPreviewItems.clear();
        List list = this.mCurrentPreviewItems;
        FolderGridOrganizer folderGridOrganizer = this.mPreviewVerifier;
        folderGridOrganizer.setFolderInfo(this.mInfo);
        list.addAll(folderGridOrganizer.previewItemsForPage(0, this.mInfo.contents));
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        PreviewItemManager previewItemManager = this.mPreviewItemManager;
        for (int i10 = 0; i10 < previewItemManager.mFirstPageParams.size(); i10++) {
            if (((PreviewItemDrawingParams) previewItemManager.mFirstPageParams.get(i10)).drawable == drawable) {
                return true;
            }
        }
        return super.verifyDrawable(drawable);
    }

    public FolderIcon(Context context) {
        this(context, null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v1, types: [com.android.launcher3.model.data.ItemInfo] */
    /* JADX WARN: Type inference failed for: r9v0, types: [android.widget.FrameLayout, com.android.launcher3.folder.FolderIcon] */
    public final void onDrop(DropTarget.DragObject dragObject, boolean z10) {
        Object workspaceItemInfo;
        int size;
        Object obj = dragObject.dragInfo;
        if (obj instanceof WorkspaceItemFactory) {
            workspaceItemInfo = ((WorkspaceItemFactory) obj).makeWorkspaceItem(getContext());
        } else {
            workspaceItemInfo = obj;
            if (dragObject.dragSource instanceof BaseItemDragListener) {
                if (obj instanceof AppPairInfo) {
                    AppPairInfo appPairInfo = (AppPairInfo) dragObject.dragInfo;
                    AppPairInfo appPairInfo2 = new AppPairInfo();
                    appPairInfo2.contents = new ArrayList(appPairInfo.contents);
                    appPairInfo2.copyFrom(appPairInfo);
                    workspaceItemInfo = appPairInfo2;
                } else {
                    workspaceItemInfo = new WorkspaceItemInfo((WorkspaceItemInfo) dragObject.dragInfo);
                }
            }
        }
        ?? r32 = workspaceItemInfo;
        Folder folder = this.mFolder;
        if (folder.mIsDragInProgress) {
            folder.mItemAddedBackToSelfViaIcon = true;
        }
        if (z10) {
            size = r32.rank;
        } else {
            size = this.mInfo.contents.size();
        }
        onDrop(r32, dragObject, null, 1.0f, size, z10);
    }
}
