package com.android.launcher3.folder;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import com.android.launcher3.CellLayout;

/* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
/* JADX INFO: loaded from: classes.dex */
public final class FolderOpenCloseAnimationListener extends AnimatorListenerAdapter {
    public CellLayout cellLayout;
    public boolean cellLayoutClipChildren;
    public boolean cellLayoutClipPadding;
    public boolean contentClipChildren;
    public boolean contentClipToPadding;
    public Folder folder;
    public boolean folderClipChildren;
    public boolean folderClipToPadding;

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        super.onAnimationEnd(animator);
        Folder folder = this.folder;
        folder.setTranslationX(0.0f);
        folder.setTranslationY(0.0f);
        folder.setTranslationZ(0.0f);
        folder.mContent.setScaleX(1.0f);
        folder.mContent.setScaleY(1.0f);
        folder.mFooter.setScaleX(1.0f);
        folder.mFooter.setScaleY(1.0f);
        folder.mFooter.setTranslationX(0.0f);
        folder.mFolderName.setAlpha(1.0f);
        folder.mContent.setClipPath(null);
        folder.setClipPath(null);
        folder.setClipChildren(this.folderClipChildren);
        folder.setClipToPadding(this.folderClipToPadding);
        folder.mContent.setClipChildren(this.contentClipChildren);
        folder.mContent.setClipToPadding(this.contentClipToPadding);
        CellLayout cellLayout = this.cellLayout;
        if (cellLayout != null) {
            cellLayout.setClipChildren(this.cellLayoutClipChildren);
        }
        CellLayout cellLayout2 = this.cellLayout;
        if (cellLayout2 != null) {
            cellLayout2.setClipToPadding(this.cellLayoutClipPadding);
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
        super.onAnimationStart(animator);
        Folder folder = this.folder;
        this.folderClipChildren = folder.getClipChildren();
        this.folderClipToPadding = folder.getClipToPadding();
        this.contentClipChildren = folder.mContent.getClipChildren();
        this.contentClipToPadding = folder.mContent.getClipToPadding();
        FolderPagedView folderPagedView = folder.mContent;
        CellLayout cellLayout = (CellLayout) folderPagedView.getChildAt(folderPagedView.getNextPage());
        this.cellLayout = cellLayout;
        this.cellLayoutClipChildren = cellLayout != null ? cellLayout.getClipChildren() : false;
        CellLayout cellLayout2 = this.cellLayout;
        this.cellLayoutClipPadding = cellLayout2 != null ? cellLayout2.getClipToPadding() : false;
        folder.setClipChildren(false);
        folder.setClipToPadding(false);
        folder.mContent.setClipChildren(false);
        folder.mContent.setClipToPadding(false);
        CellLayout cellLayout3 = this.cellLayout;
        if (cellLayout3 != null) {
            cellLayout3.setClipChildren(false);
        }
        CellLayout cellLayout4 = this.cellLayout;
        if (cellLayout4 != null) {
            cellLayout4.setClipToPadding(false);
        }
    }
}
