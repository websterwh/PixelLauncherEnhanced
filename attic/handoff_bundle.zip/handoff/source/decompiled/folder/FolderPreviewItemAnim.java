package com.android.launcher3.folder;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.FloatArrayEvaluator;
import android.animation.ObjectAnimator;
import android.util.Property;

/* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
/* JADX INFO: loaded from: classes.dex */
public final class FolderPreviewItemAnim {
    public final float[] finalState;
    public final ObjectAnimator mAnimator;
    public final PreviewItemManager mItemManager;
    public final PreviewItemDrawingParams mParams;
    public static final AnonymousClass1 PARAMS = new AnonymousClass1(float[].class, "params");
    public static final PreviewItemDrawingParams sTmpParams = new PreviewItemDrawingParams(0.0f, 0.0f, 0.0f);
    public static final float[] sTempParamsArray = new float[3];

    /* JADX INFO: renamed from: com.android.launcher3.folder.FolderPreviewItemAnim$1, reason: invalid class name */
    /* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
    public final class AnonymousClass1 extends Property {
        @Override // android.util.Property
        public final Object get(Object obj) {
            float[] fArr = FolderPreviewItemAnim.sTempParamsArray;
            PreviewItemDrawingParams previewItemDrawingParams = ((FolderPreviewItemAnim) obj).mParams;
            fArr[0] = previewItemDrawingParams.scale;
            fArr[1] = previewItemDrawingParams.transX;
            fArr[2] = previewItemDrawingParams.transY;
            return fArr;
        }

        @Override // android.util.Property
        public final void set(Object obj, Object obj2) {
            FolderPreviewItemAnim folderPreviewItemAnim = (FolderPreviewItemAnim) obj;
            float[] fArr = (float[]) obj2;
            PreviewItemDrawingParams previewItemDrawingParams = folderPreviewItemAnim.mParams;
            previewItemDrawingParams.scale = fArr[0];
            previewItemDrawingParams.transX = fArr[1];
            previewItemDrawingParams.transY = fArr[2];
            folderPreviewItemAnim.mItemManager.mIcon.invalidate();
        }
    }

    public FolderPreviewItemAnim(PreviewItemManager previewItemManager, final PreviewItemDrawingParams previewItemDrawingParams, int i10, int i11, int i12, int i13, int i14, final Runnable runnable) {
        this.mItemManager = previewItemManager;
        this.mParams = previewItemDrawingParams;
        previewItemDrawingParams.index = i12;
        PreviewItemDrawingParams previewItemDrawingParams2 = sTmpParams;
        previewItemManager.computePreviewItemDrawingParams(i12, i13, previewItemDrawingParams2);
        float[] fArr = {previewItemDrawingParams2.scale, previewItemDrawingParams2.transX, previewItemDrawingParams2.transY};
        this.finalState = fArr;
        previewItemManager.computePreviewItemDrawingParams(i10, i11, previewItemDrawingParams2);
        ObjectAnimator objectAnimatorOfObject = ObjectAnimator.ofObject(this, PARAMS, new FloatArrayEvaluator(), new float[]{previewItemDrawingParams2.scale, previewItemDrawingParams2.transX, previewItemDrawingParams2.transY}, fArr);
        this.mAnimator = objectAnimatorOfObject;
        objectAnimatorOfObject.addListener(new AnimatorListenerAdapter() { // from class: com.android.launcher3.folder.FolderPreviewItemAnim.2
            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator) {
                Runnable runnable2 = runnable;
                if (runnable2 != null) {
                    runnable2.run();
                }
                previewItemDrawingParams.anim = null;
            }
        });
        objectAnimatorOfObject.setDuration(i14);
    }
}
