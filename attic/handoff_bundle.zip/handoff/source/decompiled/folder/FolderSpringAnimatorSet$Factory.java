package com.android.launcher3.folder;

import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import android.content.Context;
import android.util.FloatProperty;
import com.android.launcher3.anim.SpringAnimationBuilder;

/* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
/* JADX INFO: loaded from: classes.dex */
public abstract class FolderSpringAnimatorSet$Factory {
    public static void playSpringAnimation(Context context, AnimatorSet animatorSet, boolean z10, int i10, float f10, float f11, float f12, float f13, float f14, FloatProperty floatProperty, Object obj) {
        SpringAnimationBuilder springAnimationBuilder = new SpringAnimationBuilder(context);
        springAnimationBuilder.setStiffness(f10);
        springAnimationBuilder.setDampingRatio(f11);
        springAnimationBuilder.mStartValue = z10 ? f12 : f13;
        if (z10) {
            f12 = f13;
        }
        springAnimationBuilder.mEndValue = f12;
        springAnimationBuilder.setMinimumVisibleChange(f14);
        ValueAnimator valueAnimatorBuild = springAnimationBuilder.build(obj, floatProperty);
        valueAnimatorBuild.setStartDelay(i10);
        animatorSet.play(valueAnimatorBuild);
    }
}
