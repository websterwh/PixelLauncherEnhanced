package com.android.launcher3.folder;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.util.Property;
import android.view.View;
import android.view.animation.Interpolator;
import com.android.app.animation.Interpolators;
import com.android.launcher3.CellLayout;
import com.android.launcher3.R$styleable;
import com.android.launcher3.celllayout.DelegatedCellDrawing;
import com.android.launcher3.deviceprofile.FolderProfile;
import com.android.launcher3.graphics.PathWrapper;
import com.android.launcher3.graphics.ThemeManager;
import com.android.launcher3.views.ActivityContext;
import java.lang.invoke.VarHandle;

/* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
/* JADX INFO: loaded from: classes.dex */
public final class PreviewBackground extends DelegatedCellDrawing {
    protected static final float ACCEPT_SCALE_FACTOR = 1.2f;
    protected static final int CONSUMPTION_ANIMATION_DURATION = 100;
    protected static final int HOVER_ANIMATION_DURATION = 300;
    protected static final float HOVER_SCALE = 1.1f;
    public int basePreviewOffsetX;
    public int basePreviewOffsetY;
    public int mBgColor;
    public final Context mContext;
    public CellLayout mDrawingDelegate;
    public View mInvalidateDelegate;
    protected boolean mIsAccepting;
    protected boolean mIsHovered;
    protected boolean mIsHoveredOrAnimating;
    public final Paint mPaint;
    public final PathWrapper mPath;
    public float mScale;
    protected ValueAnimator mScaleAnimator;
    public int mShadowAlpha;
    public int mStrokeAlpha;
    public int previewSize;

    static {
        final int i10 = 0;
        Class<Integer> cls = Integer.class;
        new Property(cls, "strokeAlpha") { // from class: com.android.launcher3.folder.PreviewBackground.1
            @Override // android.util.Property
            public final Object get(Object obj) {
                switch (i10) {
                    case 0:
                        return Integer.valueOf(((PreviewBackground) obj).mStrokeAlpha);
                    default:
                        return Integer.valueOf(((PreviewBackground) obj).mShadowAlpha);
                }
            }

            @Override // android.util.Property
            public final void set(Object obj, Object obj2) {
                switch (i10) {
                    case 0:
                        PreviewBackground previewBackground = (PreviewBackground) obj;
                        previewBackground.mStrokeAlpha = ((Integer) obj2).intValue();
                        previewBackground.invalidate();
                        break;
                    default:
                        PreviewBackground previewBackground2 = (PreviewBackground) obj;
                        previewBackground2.mShadowAlpha = ((Integer) obj2).intValue();
                        previewBackground2.invalidate();
                        break;
                }
            }
        };
        final int i11 = 1;
        new Property(cls, "shadowAlpha") { // from class: com.android.launcher3.folder.PreviewBackground.1
            @Override // android.util.Property
            public final Object get(Object obj) {
                switch (i11) {
                    case 0:
                        return Integer.valueOf(((PreviewBackground) obj).mStrokeAlpha);
                    default:
                        return Integer.valueOf(((PreviewBackground) obj).mShadowAlpha);
                }
            }

            @Override // android.util.Property
            public final void set(Object obj, Object obj2) {
                switch (i11) {
                    case 0:
                        PreviewBackground previewBackground = (PreviewBackground) obj;
                        previewBackground.mStrokeAlpha = ((Integer) obj2).intValue();
                        previewBackground.invalidate();
                        break;
                    default:
                        PreviewBackground previewBackground2 = (PreviewBackground) obj;
                        previewBackground2.mShadowAlpha = ((Integer) obj2).intValue();
                        previewBackground2.invalidate();
                        break;
                }
            }
        };
    }

    public PreviewBackground(Context context) {
        new PorterDuffXfermode(PorterDuff.Mode.DST_OUT);
        new Matrix();
        this.mPath = new PathWrapper();
        this.mPaint = new Paint(1);
        this.mScale = 1.0f;
        this.mStrokeAlpha = 255;
        this.mShadowAlpha = 255;
        this.mContext = context;
    }

    public final void animateScale(boolean z10, boolean z11) {
        ValueAnimator valueAnimator = this.mScaleAnimator;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        float f10 = this.mScale;
        float f11 = z10 ? ACCEPT_SCALE_FACTOR : z11 ? HOVER_SCALE : 1.0f;
        boolean z12 = this.mIsAccepting;
        Interpolator interpolator = z10 != z12 ? Interpolators.ACCELERATE_DECELERATE : Interpolators.EMPHASIZED_DECELERATE;
        int i10 = z10 != z12 ? CONSUMPTION_ANIMATION_DURATION : HOVER_ANIMATION_DURATION;
        this.mIsAccepting = z10;
        this.mIsHovered = z11;
        if (f10 == f11) {
            if (!z10) {
                CellLayout cellLayout = this.mDrawingDelegate;
                if (cellLayout != null) {
                    cellLayout.mDelegatedCellDrawings.remove(this);
                }
                this.mDrawingDelegate = null;
                invalidate();
            }
            this.mIsHoveredOrAnimating = this.mIsHovered;
            return;
        }
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        this.mScaleAnimator = valueAnimatorOfFloat;
        PreviewBackground$$ExternalSyntheticLambda0 previewBackground$$ExternalSyntheticLambda0 = new PreviewBackground$$ExternalSyntheticLambda0();
        previewBackground$$ExternalSyntheticLambda0.f10381c = this;
        previewBackground$$ExternalSyntheticLambda0.f10382e = f11;
        previewBackground$$ExternalSyntheticLambda0.f10383f = f10;
        VarHandle.storeStoreFence();
        valueAnimatorOfFloat.addUpdateListener(previewBackground$$ExternalSyntheticLambda0);
        this.mScaleAnimator.addListener(new AnimatorListenerAdapter() { // from class: com.android.launcher3.folder.PreviewBackground.5
            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator) {
                PreviewBackground previewBackground = PreviewBackground.this;
                if (!previewBackground.mIsAccepting) {
                    CellLayout cellLayout2 = previewBackground.mDrawingDelegate;
                    if (cellLayout2 != null) {
                        cellLayout2.mDelegatedCellDrawings.remove(previewBackground);
                    }
                    previewBackground.mDrawingDelegate = null;
                    previewBackground.invalidate();
                }
                PreviewBackground previewBackground2 = PreviewBackground.this;
                previewBackground2.mIsHoveredOrAnimating = previewBackground2.mIsHovered;
                previewBackground2.mScaleAnimator = null;
            }

            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public final void onAnimationStart(Animator animator) {
                PreviewBackground previewBackground = PreviewBackground.this;
                if (previewBackground.mIsHovered) {
                    previewBackground.mIsHoveredOrAnimating = true;
                }
            }
        });
        this.mScaleAnimator.setInterpolator(interpolator);
        this.mScaleAnimator.setDuration(i10);
        this.mScaleAnimator.start();
    }

    public final void animateToAccept(CellLayout cellLayout, int i10, int i11) {
        if (this.mDrawingDelegate != cellLayout) {
            cellLayout.mDelegatedCellDrawings.add(this);
        }
        this.mDrawingDelegate = cellLayout;
        this.mDelegateCellX = i10;
        this.mDelegateCellY = i11;
        invalidate();
        animateScale(true, this.mIsHovered);
    }

    public final void animateToRest() {
        animateScale(false, this.mIsHovered);
    }

    public final void drawBackground(Canvas canvas) {
        this.mPaint.setStyle(Paint.Style.FILL);
        this.mPaint.setColor(this.mBgColor);
        ((ThemeManager) ThemeManager.INSTANCE.get(this.mContext)).iconState.folderShape.drawShape(canvas, this.basePreviewOffsetX - (getScaledRadius() - (this.previewSize / 2)), this.basePreviewOffsetY - (getScaledRadius() - (this.previewSize / 2)), getScaledRadius(), this.mPaint);
    }

    public final void drawLeaveBehind(Canvas canvas, int i10) {
        float f10 = this.mScale;
        this.mScale = 0.5f;
        this.mPaint.setStyle(Paint.Style.FILL);
        this.mPaint.setColor(i10);
        ((ThemeManager) ThemeManager.INSTANCE.get(this.mContext)).iconState.folderShape.drawShape(canvas, this.basePreviewOffsetX - (getScaledRadius() - (this.previewSize / 2)), this.basePreviewOffsetY - (getScaledRadius() - (this.previewSize / 2)), getScaledRadius(), this.mPaint);
        this.mScale = f10;
    }

    @Override // com.android.launcher3.celllayout.DelegatedCellDrawing
    public final void drawUnderItem(Canvas canvas) {
        drawBackground(canvas);
    }

    public final int getScaledRadius() {
        return (int) (this.mScale * (this.previewSize / 2));
    }

    public final void invalidate() {
        View view = this.mInvalidateDelegate;
        if (view != null) {
            view.invalidate();
        }
        CellLayout cellLayout = this.mDrawingDelegate;
        if (cellLayout != null) {
            cellLayout.invalidate();
        }
    }

    public final void setup(Context context, ActivityContext activityContext, View view, int i10, int i11) {
        this.mInvalidateDelegate = view;
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(R$styleable.FolderIconPreview);
        typedArrayObtainStyledAttributes.getColor(0, 0);
        this.mBgColor = typedArrayObtainStyledAttributes.getColor(1, 0);
        typedArrayObtainStyledAttributes.recycle();
        FolderProfile folderProfile = activityContext.getDeviceProfile().mFolderProfile;
        int i12 = folderProfile.folderIconSizePx;
        this.previewSize = i12;
        this.basePreviewOffsetX = (i10 - i12) / 2;
        this.basePreviewOffsetY = i11 + folderProfile.folderIconOffsetYPx;
        float f10 = context.getResources().getDisplayMetrics().density;
        invalidate();
    }
}
