package com.android.launcher3.folder;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.FloatProperty;
import com.android.launcher3.Utilities;
import com.android.launcher3.folder.LauncherDelegate;
import com.android.launcher3.graphics.PathWrapper;
import com.android.launcher3.graphics.ThemeManager;
import com.android.launcher3.model.data.ItemInfo;
import com.android.launcher3.popup.ArrowPopup;
import com.android.launcher3.views.ActivityContext;
import java.util.ArrayList;
import java.util.Arrays;

/* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
/* JADX INFO: loaded from: classes.dex */
public final class PreviewItemManager {
    public static final AnonymousClass1 CURRENT_PAGE_ITEMS_TRANS_X = new AnonymousClass1("currentPageItemsTransX");
    public final float mClipThreshold;
    public final Context mContext;
    public final FolderIcon mIcon;
    public final int mIconSize;
    public boolean mShouldSlideInFirstPage;
    public float mIntrinsicIconSize = -1.0f;
    public int mTotalWidth = -1;
    public int mPrevTopPadding = -1;
    public Drawable mReferenceDrawable = null;
    public int mNumOfPrevItems = 0;
    public final ArrayList mFirstPageParams = new ArrayList();
    public final ArrayList mCurrentPageParams = new ArrayList();
    public float mCurrentPageItemsTransX = 0.0f;

    /* JADX INFO: renamed from: com.android.launcher3.folder.PreviewItemManager$1, reason: invalid class name */
    /* JADX INFO: compiled from: go/retraceme 8bcbbc35bb13161dedaa519f339f298517b051dcbf8e2046701ae935fa579434 */
    public final class AnonymousClass1 extends FloatProperty {
        @Override // android.util.Property
        public final Float get(Object obj) {
            return Float.valueOf(((PreviewItemManager) obj).mCurrentPageItemsTransX);
        }

        @Override // android.util.FloatProperty
        public final void setValue(Object obj, float f10) {
            PreviewItemManager previewItemManager = (PreviewItemManager) obj;
            previewItemManager.mCurrentPageItemsTransX = f10;
            previewItemManager.mIcon.invalidate();
        }
    }

    public PreviewItemManager(FolderIcon folderIcon) {
        Context context = folderIcon.getContext();
        this.mContext = context;
        this.mIcon = folderIcon;
        this.mIconSize = ((ActivityContext) ActivityContext.lookupContext(context)).getDeviceProfile().mFolderProfile.childIconSizePx;
        this.mClipThreshold = Utilities.dpToPx(1.0f);
    }

    public final void buildParamsForPage(int i10, ArrayList arrayList, boolean z10) {
        PreviewItemManager previewItemManager;
        FolderIcon folderIcon = this.mIcon;
        FolderGridOrganizer folderGridOrganizer = folderIcon.mPreviewVerifier;
        folderGridOrganizer.setFolderInfo(folderIcon.mInfo);
        ArrayList arrayListPreviewItemsForPage = folderGridOrganizer.previewItemsForPage(i10, folderIcon.mInfo.contents);
        while (arrayListPreviewItemsForPage.size() < arrayList.size()) {
            arrayList.remove(arrayList.size() - 1);
        }
        while (arrayListPreviewItemsForPage.size() > arrayList.size()) {
            arrayList.add(new PreviewItemDrawingParams(0.0f, 0.0f, 0.0f));
        }
        int size = i10 == 0 ? arrayListPreviewItemsForPage.size() : 4;
        int i11 = 0;
        while (i11 < arrayList.size()) {
            PreviewItemDrawingParams previewItemDrawingParams = (PreviewItemDrawingParams) arrayList.get(i11);
            this.setDrawable(previewItemDrawingParams, (ItemInfo) arrayListPreviewItemsForPage.get(i11));
            if (z10) {
                previewItemManager = this;
                FolderPreviewItemAnim folderPreviewItemAnim = new FolderPreviewItemAnim(previewItemManager, previewItemDrawingParams, i11, this.mNumOfPrevItems, i11, size, 400, null);
                FolderPreviewItemAnim folderPreviewItemAnim2 = previewItemDrawingParams.anim;
                if (folderPreviewItemAnim2 == null) {
                    previewItemDrawingParams.anim = folderPreviewItemAnim;
                    folderPreviewItemAnim.mAnimator.start();
                } else if (!Arrays.equals(folderPreviewItemAnim2.finalState, folderPreviewItemAnim.finalState)) {
                    previewItemDrawingParams.anim.mAnimator.cancel();
                    previewItemDrawingParams.anim = folderPreviewItemAnim;
                    folderPreviewItemAnim.mAnimator.start();
                }
            } else {
                FolderPreviewItemAnim folderPreviewItemAnim3 = previewItemDrawingParams.anim;
                if (folderPreviewItemAnim3 != null) {
                    folderPreviewItemAnim3.mAnimator.cancel();
                }
                this.computePreviewItemDrawingParams(i11, size, previewItemDrawingParams);
                if (this.mReferenceDrawable == null) {
                    this.mReferenceDrawable = previewItemDrawingParams.drawable;
                }
                previewItemManager = this;
            }
            i11++;
            this = previewItemManager;
        }
    }

    public final void computePreviewDrawingParams(int i10, int i11) {
        float f10 = this.mIntrinsicIconSize;
        float f11 = i10;
        FolderIcon folderIcon = this.mIcon;
        if (f10 == f11 && this.mTotalWidth == i11 && this.mPrevTopPadding == folderIcon.getPaddingTop()) {
            return;
        }
        this.mIntrinsicIconSize = f11;
        this.mTotalWidth = i11;
        this.mPrevTopPadding = folderIcon.getPaddingTop();
        folderIcon.mBackground.setup(folderIcon.getContext(), folderIcon.mActivity, folderIcon, this.mTotalWidth, folderIcon.getPaddingTop());
        ClippedFolderIconLayoutRule clippedFolderIconLayoutRule = folderIcon.mPreviewLayoutRule;
        int i12 = folderIcon.mBackground.previewSize;
        float f12 = this.mIntrinsicIconSize;
        boolean zIsRtl = Utilities.isRtl(folderIcon.getResources());
        int i13 = folderIcon.mActivity.getDeviceProfile().mFolderProfile.numColumns;
        float f13 = i12;
        clippedFolderIconLayoutRule.mAvailableSpace = f13;
        clippedFolderIconLayoutRule.mRadius = (1.2f * f13) / 2.0f;
        clippedFolderIconLayoutRule.mIconSize = f12;
        clippedFolderIconLayoutRule.mIsRtl = zIsRtl;
        clippedFolderIconLayoutRule.mBaselineIconScale = f13 / f12;
        int size = this.mFirstPageParams.size();
        buildParamsForPage(0, this.mFirstPageParams, false);
        this.mNumOfPrevItems = size;
    }

    public final PreviewItemDrawingParams computePreviewItemDrawingParams(int i10, int i11, PreviewItemDrawingParams previewItemDrawingParams) {
        FolderIcon folderIcon = this.mIcon;
        if (i10 == -1) {
            float f10 = folderIcon.mActivity.getDeviceProfile().mWorkspaceProfile.iconSizePx;
            float f11 = (folderIcon.mBackground.previewSize - f10) / 2.0f;
            previewItemDrawingParams.update(f11, f11, f10 / this.mReferenceDrawable.getIntrinsicWidth());
            return previewItemDrawingParams;
        }
        ClippedFolderIconLayoutRule clippedFolderIconLayoutRule = folderIcon.mPreviewLayoutRule;
        float[] fArr = clippedFolderIconLayoutRule.mTmpPoint;
        float fScaleForItem = clippedFolderIconLayoutRule.scaleForItem(i11, 0);
        if (i10 == -2) {
            clippedFolderIconLayoutRule.getGridPosition(0, 2, fArr);
        } else if (i10 == -3) {
            clippedFolderIconLayoutRule.getGridPosition(1, 2, fArr);
        } else if (i10 >= 4) {
            float f12 = (clippedFolderIconLayoutRule.mAvailableSpace / 2.0f) - ((clippedFolderIconLayoutRule.mIconSize * fScaleForItem) / 2.0f);
            fArr[1] = f12;
            fArr[0] = f12;
        } else {
            clippedFolderIconLayoutRule.getPosition(i10, i11, fArr);
        }
        float f13 = fArr[0];
        float f14 = fArr[1];
        if (previewItemDrawingParams == null) {
            return new PreviewItemDrawingParams(f13, f14, fScaleForItem);
        }
        previewItemDrawingParams.update(f13, f14, fScaleForItem);
        return previewItemDrawingParams;
    }

    public final FolderPreviewItemAnim createFirstItemAnimation(boolean z10, LauncherDelegate.AnonymousClass1 anonymousClass1) {
        return z10 ? new FolderPreviewItemAnim(this, (PreviewItemDrawingParams) this.mFirstPageParams.get(0), 0, 2, -1, -1, ArrowPopup.OPEN_DURATION_U, anonymousClass1) : new FolderPreviewItemAnim(this, (PreviewItemDrawingParams) this.mFirstPageParams.get(0), -1, -1, 0, 2, 350, anonymousClass1);
    }

    public final void draw(Canvas canvas) {
        PreviewItemManager previewItemManager;
        Canvas canvas2;
        float f10;
        int saveCount = canvas.getSaveCount();
        PreviewBackground previewBackground = this.mIcon.mBackground;
        PathWrapper pathWrapper = previewBackground.mPath;
        pathWrapper.path.reset();
        float scaledRadius = previewBackground.getScaledRadius();
        float f11 = scaledRadius - (previewBackground.previewSize / 2);
        ((ThemeManager) ThemeManager.INSTANCE.get(previewBackground.mContext)).iconState.folderShape.addToPath(pathWrapper, previewBackground.basePreviewOffsetX - f11, previewBackground.basePreviewOffsetY - f11, scaledRadius);
        Path path = pathWrapper.path;
        boolean z10 = this.mShouldSlideInFirstPage;
        float f12 = this.mClipThreshold;
        if (z10) {
            previewItemManager = this;
            canvas2 = canvas;
            previewItemManager.drawParams(canvas2, this.mCurrentPageParams, new PointF(previewBackground.basePreviewOffsetX + this.mCurrentPageItemsTransX, previewBackground.basePreviewOffsetY), this.mCurrentPageItemsTransX > f12, path);
            f10 = previewItemManager.mCurrentPageItemsTransX - 200.0f;
        } else {
            previewItemManager = this;
            canvas2 = canvas;
            f10 = 0.0f;
        }
        previewItemManager.drawParams(canvas2, previewItemManager.mFirstPageParams, new PointF(previewBackground.basePreviewOffsetX + f10, previewBackground.basePreviewOffsetY), f10 < (-f12), path);
        canvas2.restoreToCount(saveCount);
    }

    public final void drawParams(Canvas canvas, ArrayList arrayList, PointF pointF, boolean z10, Path path) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            PreviewItemDrawingParams previewItemDrawingParams = (PreviewItemDrawingParams) arrayList.get(size);
            if (!previewItemDrawingParams.hidden) {
                boolean z11 = (previewItemDrawingParams.index == -2.0f) | z10;
                canvas.save();
                if (z11) {
                    canvas.clipPath(path);
                }
                canvas.translate(pointF.x + previewItemDrawingParams.transX, pointF.y + previewItemDrawingParams.transY);
                float f10 = previewItemDrawingParams.scale;
                canvas.scale(f10, f10);
                Drawable drawable = previewItemDrawingParams.drawable;
                if (drawable != null) {
                    Rect bounds = drawable.getBounds();
                    canvas.save();
                    canvas.translate(-bounds.left, -bounds.top);
                    canvas.scale(this.mIntrinsicIconSize / bounds.width(), this.mIntrinsicIconSize / bounds.height());
                    drawable.draw(canvas);
                    canvas.restore();
                }
                canvas.restore();
            }
        }
    }

    public final void hidePreviewItem(int i10, boolean z10) {
        int iMax = Math.max(this.mFirstPageParams.size() - 4, 0) + i10;
        PreviewItemDrawingParams previewItemDrawingParams = iMax < this.mFirstPageParams.size() ? (PreviewItemDrawingParams) this.mFirstPageParams.get(iMax) : null;
        if (previewItemDrawingParams != null) {
            previewItemDrawingParams.hidden = z10;
        }
    }

    public final void recomputePreviewDrawingParams() {
        Drawable drawable = this.mReferenceDrawable;
        if (drawable != null) {
            computePreviewDrawingParams(drawable.getIntrinsicWidth(), this.mIcon.getMeasuredWidth());
        }
    }

    public void setDrawable(PreviewItemDrawingParams previewItemDrawingParams, ItemInfo itemInfo) {
        setDrawableInternal(previewItemDrawingParams, itemInfo, true);
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x004e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void setDrawableInternal(com.android.launcher3.folder.PreviewItemDrawingParams r6, com.android.launcher3.model.data.ItemInfo r7, boolean r8) {
        /*
            Method dump skipped, instruction units count: 219
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.launcher3.folder.PreviewItemManager.setDrawableInternal(com.android.launcher3.folder.PreviewItemDrawingParams, com.android.launcher3.model.data.ItemInfo, boolean):void");
    }

    public final void updateTransitionParam(PreviewItemDrawingParams previewItemDrawingParams, ItemInfo itemInfo, int i10, int i11, int i12) {
        setDrawable(previewItemDrawingParams, itemInfo);
        FolderPreviewItemAnim folderPreviewItemAnim = new FolderPreviewItemAnim(this, previewItemDrawingParams, i10, i12, i11, i12, 400, null);
        FolderPreviewItemAnim folderPreviewItemAnim2 = previewItemDrawingParams.anim;
        if (folderPreviewItemAnim2 != null && !Arrays.equals(folderPreviewItemAnim2.finalState, folderPreviewItemAnim.finalState)) {
            previewItemDrawingParams.anim.mAnimator.cancel();
        }
        previewItemDrawingParams.anim = folderPreviewItemAnim;
    }
}
